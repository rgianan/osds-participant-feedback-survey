/** Code.gs — Survey + Admin server (dedupe, validations, admin endpoints)
 * Deploy: Web app → Execute as "Me", Who has access "Anyone" (or your domain)
 */

// --------------------------- Switches / Folder IDs ---------------------------
var ENFORCE_WHITELIST = true; // gate /?admin behind Whitelist

// Folder for certificate templates (Google Slides preferred; PPT/PPTX will be converted)
var TEMPLATE_FOLDER_ID = '1p621gez5fInaAywXdy7vqoyqQfQctlkY';
// Folder where generated certificate PDFs will be stored
var CERTIFICATES_FOLDER_ID = '1wvfjg33QkmO_WkRsDJuW5QTMBWCJ-8T8';

// --------------------------- Web app entry ---------------------------
function doGet(e) {
  var p = (e && e.parameter) || {};
  var requested = (p.page ? String(p.page).toLowerCase() : (p.admin ? 'admin' : 'index'));

  var file = (requested === 'submit') ? 'submit'
           : (requested === 'admin')  ? 'admin'
           : 'index';

  // STRICT GATE: never send admin.html unless whitelisted
  if (file === 'admin') {
    var email = getViewerEmail_();            // blank for “Anyone with Google account” deployments
    var allowed = !!email && isWhitelisted_(email);
    if (!allowed) {
      var html = HtmlService.createHtmlOutput(
        '<!doctype html><meta charset="utf-8">' +
        '<style>body{font-family:system-ui,Segoe UI,Roboto,Arial,sans-serif;background:#f7f9fb;margin:0;padding:40px;color:#24323f}' +
        '.card{max-width:720px;margin:40px auto;background:#fff;border:1px solid #edf0f2;border-radius:14px;box-shadow:0 6px 14px rgba(10,30,60,.06);padding:22px}' +
        'h1{margin:0 0 8px;font-size:1.35rem;color:#1b5e20} .muted{color:#6b7c93} a.btn{display:inline-block;margin-top:14px;padding:12px 16px;border-radius:12px;' +
        'background:#eaf7ec;color:#1b5e20;text-decoration:none;border:1px solid #cfe0d0;font-weight:700}</style>' +
        '<div class="card"><h1>Forbidden</h1>' +
        '<p class="muted">You are not authorized to view this page.</p>' +
        '<div id="backWrap"><a class="btn" href="#" id="backBtn">← Back to survey</a></div>' +
        '<script>google.script.run.withSuccessHandler(function(base){' +
        'var a=document.getElementById("backBtn"); if(a) a.href=base;}).getWebAppUrl();<\/script></div>'
      );
      return html.setTitle('Forbidden').setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
    }
  }

  return HtmlService
    .createHtmlOutputFromFile('Portal')
    .setTitle(file === 'submit' ? 'Submission • Participant Feedback'
            : file === 'admin'  ? 'Admin • Activity Manager'
            : 'Participant Feedback Survey')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

// --------------------------- HTML include helper ---------------------------
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}
function getWebAppUrl() {
  return ScriptApp.getService().getUrl();
}

// ------------------------------ Utilities ---------------------------
function safeTrim_(v){ return String(v == null ? '' : v).trim(); }
function getViewerEmail_(){ return safeTrim_(Session.getActiveUser().getEmail() || ''); }

function getHeaderMap_(sheet) {
  var lastCol = sheet.getLastColumn();
  if (lastCol < 1) return {};
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0]
    .map(function(h){ return String(h || '').trim(); });
  var map = {};
  headers.forEach(function(h, i){
    if (!h) return;
    map[h.toLowerCase()] = i; // 0-based
  });
  return map;
}
function idxOf_(hdrMap, candidates) {
  for (var i = 0; i < candidates.length; i++) {
    var k = String(candidates[i]).toLowerCase();
    if (k in hdrMap) return hdrMap[k];
  }
  return -1;
}
function fmtDate_(v){
  if (Object.prototype.toString.call(v) === '[object Date]' && !isNaN(v)) {
    return Utilities.formatDate(v, Session.getScriptTimeZone() || 'Asia/Manila', 'yyyy-MM-dd');
  }
  return safeTrim_(v);
}
function extractDriveFileId_(input) {
  var s = safeTrim_(input);
  if (!s) return '';
  if (/^[a-zA-Z0-9_-]{20,}$/.test(s)) return s; // already an ID
  var m =
    s.match(/\/d\/([a-zA-Z0-9_-]{20,})\//) ||
    s.match(/[?&]id=([a-zA-Z0-9_-]{20,})/) ||
    s.match(/\/file\/d\/([a-zA-Z0-9_-]{20,})/) ||
    s.match(/^https:\/\/drive\.google\.com\/uc\?export=download&id=([a-zA-Z0-9_-]{20,})/);
  return m ? m[1] : '';
}
function assertFolder_(folderId, label){
  folderId = safeTrim_(folderId);
  if (!folderId) throw new Error(label + " is blank.");
  try {
    var f = DriveApp.getFolderById(folderId);
    f.getName(); // assert access
    return f;
  } catch (e) {
    throw new Error(label + " is invalid or inaccessible (id=" + folderId + ").");
  }
}
function parseAndAssertFile_(input, label){
  var id = extractDriveFileId_(input);
  if (!id) throw new Error(label + " is not a Drive link or file id: " + input);
  try {
    var file = DriveApp.getFileById(id);
    var mime = file.getMimeType();
    return {id:id, file:file, mime:mime};
  } catch (e) {
    throw new Error(label + " is invalid or inaccessible (id=" + id + ").");
  }
}
function makeActivityId_(){
  // Short stable-ish ID: A-xxxxxxxx (8 chars of UUID)
  return 'A-' + Utilities.getUuid().replace(/-/g,'').slice(0,8);
}

// --- Whitelist helper ---
function isWhitelisted_(email) {
  email = (email || '').trim().toLowerCase();
  if (!email) return false;
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Whitelist');
  if (!sh) return false;
  var lastRow = sh.getLastRow();
  if (lastRow < 2) return false;
  var hdr = getHeaderMap_(sh);
  var cEmail = idxOf_(hdr, ['email','e-mail']);
  if (cEmail < 0) return false;
  var values = sh.getRange(2, cEmail + 1, lastRow - 1, 1).getValues();
  for (var i = 0; i < values.length; i++) {
    var e = String(values[i][0] || '').trim().toLowerCase();
    if (e && e === email) return true;
  }
  return false;
}

// ----------------- Public: activity data for the survey ----------------
/** Returns [{id, title, venue, date}] from 'Activity'
 * Assumes ActivityID was added as the LAST column (I, after Date Given).
 */
function getActivityData() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Activity');
  if (!sh) throw new Error("Sheet 'Activity' not found.");

  var lastRow = sh.getLastRow();
  if (lastRow < 2) return [];

  var hdrMap = getHeaderMap_(sh);
  var lastCol = sh.getLastColumn();
  var rows = sh.getRange(2, 1, lastRow - 1, lastCol).getValues();

  var cTitle = idxOf_(hdrMap, ['title','activity title','activity','Title']);
  var cVenue = idxOf_(hdrMap, ['venue','location','Venue']);
  var cDate  = idxOf_(hdrMap, ['date','Date']); // single date column if present
  var cFrom  = idxOf_(hdrMap, ['fromdate','from date','start']);
  var cTo    = idxOf_(hdrMap, ['todate','to date','end']);
  var cId    = idxOf_(hdrMap, ['activityid','activity id','id']);

  var out = [];
  rows.forEach(function(r){
    var title = cTitle >= 0 ? safeTrim_(r[cTitle]) : '';
    if (!title) return;

    var venue = cVenue >= 0 ? safeTrim_(r[cVenue]) : '';
    var dateStr = '';
    if (cDate >= 0) {
      dateStr = fmtDate_(r[cDate]);
    } else {
      var fromV = cFrom >= 0 ? fmtDate_(r[cFrom]) : '';
      var toV   = cTo   >= 0 ? fmtDate_(r[cTo])   : '';
      dateStr = (fromV && toV && fromV !== toV)
        ? (fromV + ' – ' + toV)
        : (fromV || toV || '');
    }

    var id = cId >= 0 ? safeTrim_(r[cId]) : '';
    out.push({
      id: id,
      title: title,
      venue: venue,
      date : dateStr
    });
  });

  return out;
}

// ----------------- Public: load 15 questions for survey --------------
/** Returns question1..question15 from 'Questions' (row 2) */
function getQuestions() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Questions');
  if (!sh) throw new Error("Sheet 'Questions' not found.");

  var lastRow = sh.getLastRow();
  var lastCol = sh.getLastColumn();
  var out = {};
  for (var i = 1; i <= 15; i++) out['question' + i] = '';
  if (lastRow < 2 || lastCol < 1) return out;

  var hdrMap = getHeaderMap_(sh);
  var row = sh.getRange(2, 1, 1, lastCol).getValues()[0];

  function candidatesFor(j){
    return [
      'question'+j, 'Question'+j, 'QUESTION'+j,
      'question '+j, 'Question '+j, 'QUESTION '+j
    ];
  }
  for (var j = 1; j <= 15; j++) {
    var key = 'question' + j;
    var idx = idxOf_(hdrMap, candidatesFor(j));
    out[key] = safeTrim_(idx >= 0 ? (row[idx] || '') : '');
  }
  return out;
}

// ----------------- Activity lookups -----------------
function findActivityByIdOrTitle_(activityId, title) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Activity');
  if (!sh) throw new Error("Sheet 'Activity' not found.");

  var hdr = getHeaderMap_(sh);
  var cId     = idxOf_(hdr, ['activityid','activity id','id']);
  var cTitle  = idxOf_(hdr, ['title','activity title','activity']);
  if (cTitle < 0 && cId < 0) throw new Error("Activity sheet is missing Title/ActivityID columns.");

  var lastRow = sh.getLastRow(), lastCol = sh.getLastColumn();
  if (lastRow < 2) return null;
  var rows = sh.getRange(2, 1, lastRow - 1, lastCol).getValues();

  var wantId = safeTrim_(activityId).toLowerCase();
  var wantTitle = safeTrim_(title).toLowerCase();

  for (var i = 0; i < rows.length; i++) {
    var row = rows[i];
    var rowId = (cId >= 0) ? safeTrim_(row[cId]).toLowerCase() : '';
    var rowTitle = (cTitle >= 0) ? safeTrim_(row[cTitle]).toLowerCase() : '';
    var idMatch = wantId && rowId && (rowId === wantId);
    var titleMatch = wantTitle && rowTitle && (rowTitle === wantTitle);
    if (idMatch || titleMatch) {
      return { rowIndex: i + 2, row: row, header: hdr };
    }
  }
  return null;
}

// ----------------- Duplicate check (server) -----------------
/**
 * Check if a user already responded to a given Activity.
 * Match priority:
 *  1) ActivityID + Email (case-insensitive)
 *  2) ActivityID + Name (case-insensitive)
 *  3) Title + Email
 *  4) Title + Name
 * Returns: {already:boolean, by:'email'|'name'|''}
 *
 * NOTE: Rows whose status column (cStatus) starts with "ERROR"
 *       are ignored so that failed certificate/email attempts
 *       do not permanently block re-submission.
 */
function hasAlreadyResponded(name, email, activityId, title) {
  name      = safeTrim_(name).toLowerCase();
  email     = safeTrim_(email).toLowerCase();
  activityId= safeTrim_(activityId).toLowerCase();
  title     = safeTrim_(title).toLowerCase();

  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Responses');
  if (!sh) return { already: false, by: '' };

  var lastRow = sh.getLastRow();
  if (lastRow < 2) return { already: false, by: '' };

  var hdrMap = getHeaderMap_(sh);
  var lastCol = sh.getLastColumn();
  var data = sh.getRange(2, 1, lastRow - 1, lastCol).getValues();

  var cTitle  = idxOf_(hdrMap, ['title of activity','title','activity title','activity']);
  var cEmail  = idxOf_(hdrMap, ['responder email','email','e-mail']);
  var cName   = idxOf_(hdrMap, ['name']);
  var cActId  = idxOf_(hdrMap, ['activityid','activity id','id']);
  var cStatus = idxOf_(hdrMap, ['cstatus','status','processing status']); // NEW

  for (var i = data.length - 1; i >= 0; i--) {
    var row = data[i];

    // Skip rows that are explicitly in ERROR state (e.g., cert/email failed)
    if (cStatus >= 0) {
      var rowStatus = safeTrim_(row[cStatus]).toUpperCase();
      if (rowStatus.indexOf('ERROR') === 0) {
        // Treat as non-final: allow user to submit again
        continue;
      }
    }

    var rowTitle = (cTitle >= 0) ? safeTrim_(row[cTitle]).toLowerCase() : '';
    var rowEmail = (cEmail >= 0) ? safeTrim_(row[cEmail]).toLowerCase() : '';
    var rowName  = (cName  >= 0) ? safeTrim_(row[cName]).toLowerCase()  : '';
    var rowActId = (cActId >= 0) ? safeTrim_(row[cActId]).toLowerCase() : '';

    // 1) ActivityID + Email
    if (activityId && rowActId && activityId === rowActId && email && rowEmail && email === rowEmail) {
      return { already: true, by: 'email' };
    }
    // 2) ActivityID + Name
    if (activityId && rowActId && activityId === rowActId && name && rowName && name === rowName) {
      return { already: true, by: 'name' };
    }
    // 3) Title + Email
    if (title && rowTitle && title === rowTitle && email && rowEmail && email === rowEmail) {
      return { already: true, by: 'email' };
    }
    // 4) Title + Name
    if (title && rowTitle && title === rowTitle && name && rowName && name === rowName) {
      return { already: true, by: 'name' };
    }
  }
  return { already: false, by: '' };
}


function getSubmitUrl(state, title){
  var base = getWebAppUrl();
  return base + '?page=submit&state=' + encodeURIComponent(state || 'ok') +
         '&title=' + encodeURIComponent(title || '');
}

// --------- Public: append response + generate email & certificate -----
// --------- Public: append response + generate email & certificate (refactored) -----
function submitFeedback(formData) {
  var lock = LockService.getDocumentLock();
  lock.waitLock(20000);

  var nextRow = -1;

  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var sh = ss.getSheetByName('Responses');
    if (!sh) throw new Error("Sheet 'Responses' not found.");

    // If client-side email missed, try viewer email
    if (!formData.email) {
      var viewer = getViewerEmail_();
      if (viewer) formData.email = viewer;
    }

    // --- authoritative validations under document lock (NO heavy IO here) ---
    var nameT   = safeTrim_(formData.name || '');
    var emailT  = safeTrim_(formData.email || '');
    var actIdT  = safeTrim_(formData.activityId || formData.activity_id || ''); // accept either key
    var titleT  = safeTrim_(formData.title || '');
    var venueT  = safeTrim_(formData.venue || '');
    var dateT   = safeTrim_(formData.activity_date || '');

    if (!actIdT && !titleT) {
      // No row written yet → just return (finally will still release the lock)
      return { status: 'BAD_REQUEST', message: 'Activity selection is required.' };
    }

    if (!nameT) {
      return { status: 'BAD_REQUEST', message: 'Name is required.' };
    }
    if (!emailT || emailT.indexOf('@') < 0) {
      return { status: 'BAD_REQUEST', message: 'A valid email is required.' };
    }
    if (!formData.sex) {
      return { status: 'BAD_REQUEST', message: 'Sex is required.' };
    }
    var ageNum = parseInt(formData.age, 10);
    if (!ageNum || ageNum < 1 || ageNum > 120) {
      return { status: 'BAD_REQUEST', message: 'Age must be between 1 and 120.' };
    }

    // Duplicate check (race-proof: inside lock)
    var dup = hasAlreadyResponded(nameT, emailT, actIdT, titleT);
    if (dup && dup.already) {
      return { status: 'DUP', by: dup.by || '' };
    }

    // Activity existence check
    var act = findActivityByIdOrTitle_(actIdT, titleT);
    if (!act) {
      return { status: 'BAD_REQUEST', message: 'Selected activity not found. Please re-select the activity.' };
    }

    // Prepare to write row using header map (resilient to order)
    var hdrMap = getHeaderMap_(sh);
    var lastCol = sh.getLastColumn();
    nextRow = sh.getLastRow() + 1;

    // Start with an empty row array (preserve existing width)
    var rowArr = new Array(lastCol).fill('');

    function setCol_(names, value){
      var c = idxOf_(hdrMap, names);
      if (c >= 0) rowArr[c] = value;
    }

    // Set known columns (if present)
    setCol_(['timestamp','date','submitted at'], new Date());
    setCol_(['name'], formData.name || '');
    setCol_(['responder email','email','e-mail'], formData.email || '');
    setCol_(['sex'], formData.sex || '');
    setCol_(['age'], formData.age || '');
    setCol_(['activityid','activity id','id'], actIdT || '');
    setCol_(['title of activity','title','activity title','activity'], titleT || '');
    setCol_(['venue','location'], venueT || '');
    setCol_(['activity_date','date of activity','date'], dateT || '');

    // Answers 1..15
    for (var i = 1; i <= 15; i++) {
      setCol_(['answer'+i, 'q'+i, 'question'+i], safeTrim_(formData['answer'+i] || ''));
    }

    // Email sent / Certificate link / cStatus — initialized here
    setCol_(['email sent','emailsent','email_sent','sent','date emailed'], '');
    setCol_(['certificate','certificate link','cert link','certificate url'], '');
    setCol_(['cstatus','status','processing status'], 'PENDING');

    // Single write under lock
    sh.getRange(nextRow, 1, 1, lastCol).setValues([rowArr]);

    // IMPORTANT: no certificate / Drive / MailApp calls inside the lock

  } catch (e) {
    // Best-effort write error status back to the cStatus column IF we already know nextRow
    try {
      var ss2 = SpreadsheetApp.getActiveSpreadsheet();
      var sh2 = ss2.getSheetByName('Responses');
      if (nextRow > 0 && sh2) {
        var hdr2 = getHeaderMap_(sh2);
        var cStatus2 = idxOf_(hdr2, ['cstatus','status','processing status']);
        if (cStatus2 >= 0) {
          sh2.getRange(nextRow, cStatus2 + 1).setValue('ERROR: ' + e.message);
        }
      }
    } catch (_){}
    throw e; // let the client failureHandler handle it
  } finally {
    try { lock.releaseLock(); } catch (_){}
  }

  // If we reached here without an early return, we have a new row with cStatus='PENDING'.
  // Now do the heavy work (Slides/Drive/Mail) OUTSIDE the lock.

  try {
    // Create certificate & email link
    var meta = sendCertificateForResponse_(nextRow);

    // Update post-processing columns if present
    var ss3 = SpreadsheetApp.getActiveSpreadsheet();
    var sh3 = ss3.getSheetByName('Responses');
    if (sh3) {
      var hdr3 = getHeaderMap_(sh3);
      var cEmailSent = idxOf_(hdr3, ['email sent','emailsent','email_sent','sent','date emailed']);
      var cCertLink  = idxOf_(hdr3, ['certificate','certificate link','cert link','certificate url']);
      var cStatus    = idxOf_(hdr3, ['cstatus','status','processing status']);

      if (cCertLink  >= 0) sh3.getRange(nextRow, cCertLink  + 1).setValue(meta.certificateUrl || '');
      if (cEmailSent >= 0) sh3.getRange(nextRow, cEmailSent + 1).setValue(meta.emailStatus || 'No recipient email');
      if (cStatus    >= 0) sh3.getRange(nextRow, cStatus    + 1).setValue('OK');
    }

    return {
      status: 'OK',
      certificateUrl: meta.certificateUrl || '',
      emailStatus: meta.emailStatus || ''
    };
  } catch (e) {
    // Cert/email failed → mark row as ERROR but keep the response row
    try {
      var ss4 = SpreadsheetApp.getActiveSpreadsheet();
      var sh4 = ss4.getSheetByName('Responses');
      if (nextRow > 0 && sh4) {
        var hdr4 = getHeaderMap_(sh4);
        var cStatus4 = idxOf_(hdr4, ['cstatus','status','processing status']);
        if (cStatus4 >= 0) {
          sh4.getRange(nextRow, cStatus4 + 1).setValue('ERROR: ' + e.message);
        }
      }
    } catch (_){}
    throw e;
  }
}


/**
 * Creates & emails a certificate PDF for the given Responses row.
 * Placeholders in template: {{Name}}, {{Title}}, {{Venue}}, {{Date}}, {{FromDate}}, {{ToDate}}, {{GivenDate}}
 */
function sendCertificateForResponse_(responsesRowIndex) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();

  // --- Responses row lookup ---
  var respSh = ss.getSheetByName('Responses');
  if (!respSh) throw new Error("Responses sheet not found.");
  var respHdr = getHeaderMap_(respSh);
  var lastCol = respSh.getLastColumn();
  var r = respSh.getRange(responsesRowIndex, 1, 1, lastCol).getValues()[0];

  var cName   = idxOf_(respHdr, ['name']);
  var cTitle  = idxOf_(respHdr, ['title of activity','title','activity title','activity']);
  var cEmail  = idxOf_(respHdr, ['responder email','email','e-mail']);
  var cActId  = idxOf_(respHdr, ['activityid','activity id','id']);

  if (cName < 0)  throw new Error('Responses "Name" column not found.');
  if (cTitle < 0 && cActId < 0) throw new Error('Responses needs Title or ActivityID column.');

  var name  = safeTrim_(r[cName]);
  var title = (cTitle >= 0) ? safeTrim_(r[cTitle]) : '';
  var email = (cEmail >= 0) ? safeTrim_(r[cEmail]) : '';
  var activityId = (cActId >= 0) ? safeTrim_(r[cActId]) : '';

  if (!name)  throw new Error('Response "Name" is blank.');
  if (!activityId && !title) throw new Error('Response missing ActivityID/Title.');

  // --- Activity lookup (prefer ActivityID) ---
  var activity = findActivityByIdOrTitle_(activityId, title);
  if (!activity) throw new Error('No matching Activity for ActivityID/Title.');

  var actSh = ss.getSheetByName('Activity');
  var actHdr = activity.header;
  var aRow = activity.row;

  var cTpl   = idxOf_(actHdr, ['certificate template','template']);
  var cVenue = idxOf_(actHdr, ['venue','location']);
  var cDate  = idxOf_(actHdr, ['date']);
  var cFrom  = idxOf_(actHdr, ['fromdate','from date','start']);
  var cTo    = idxOf_(actHdr, ['todate','to date','end']);
  var cGiven = idxOf_(actHdr, ['givendate','given date','date given','issued','schedule']);
  var cATitle= idxOf_(actHdr, ['title','activity title','activity']);

  if (cTpl < 0) throw new Error("Activity 'Certificate Template' column missing.");

  var templateUrl = safeTrim_(aRow[cTpl]);
  var aVenue = cVenue >= 0 ? safeTrim_(aRow[cVenue]) : '';
  var aDate  = cDate  >= 0 ? fmtDate_(aRow[cDate])   : '';
  var aFrom  = cFrom  >= 0 ? fmtDate_(aRow[cFrom])   : '';
  var aTo    = cTo    >= 0 ? fmtDate_(aRow[cTo])     : '';
  var aGiven = cGiven >= 0 ? fmtDate_(aRow[cGiven])  : '';
  var aTitle = cATitle>= 0 ? safeTrim_(aRow[cATitle]): (title || '');

  if (!templateUrl) throw new Error('Missing certificate template for selected activity.');

  // --- Validate template & destination folder ---
  var tpl = parseAndAssertFile_(templateUrl, "Template");
  var certFolder = assertFolder_(CERTIFICATES_FOLDER_ID, "Certificates folder");

  // --- Prepare editable Slides doc ---
  var slidesId, baseTitle = ('Cert - ' + name + ' - ' + aTitle).slice(0, 180);
  if (tpl.mime === MimeType.GOOGLE_SLIDES) {
    slidesId = tpl.file.makeCopy(baseTitle, certFolder).getId();
  } else {
    // Convert Office → Slides
    var blob = tpl.file.getBlob();
    blob.setName(baseTitle + '.pptx');
    var created = driveCreateGoogleSlidesFromOffice_(blob, baseTitle, CERTIFICATES_FOLDER_ID);
    slidesId = created.id;
  }

  // --- Replace placeholders ---
  var pres = SlidesApp.openById(slidesId);
  pres.replaceAllText('{{Name}}', name);
  pres.replaceAllText('{{Title}}', aTitle);
  if (aVenue) pres.replaceAllText('{{Venue}}', aVenue);
  if (aDate)  pres.replaceAllText('{{Date}}', aDate);
  if (aFrom)  pres.replaceAllText('{{FromDate}}', aFrom);
  if (aTo)    pres.replaceAllText('{{ToDate}}', aTo);
  if (aGiven) pres.replaceAllText('{{GivenDate}}', aGiven);
  pres.saveAndClose();

  // --- Export to PDF, store, and share ---
  var pdfBlob = driveExportFileAsPdf_(slidesId);
  pdfBlob.setName('Certificate - ' + name + ' - ' + aTitle + '.pdf');

  var pdfFile = certFolder.createFile(pdfBlob);
  try {
    // Choose policy: ANYONE_WITH_LINK or DOMAIN_WITH_LINK
    pdfFile.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    // pdfFile.setSharing(DriveApp.Access.DOMAIN_WITH_LINK, DriveApp.Permission.VIEW);
  } catch (_){}
  var certUrl = pdfFile.getUrl();

  // --- Email link (no attachment) ---
  var emailStatus = '';
  if (email) {
    var tz = Session.getScriptTimeZone() || 'UTC';
    var sentAt = Utilities.formatDate(new Date(), tz, 'yyyy-MM-dd HH:mm');
    var subject = 'Certificate: ' + aTitle;

    var bodyText =
      'Dear ' + name + ',\n\n' +
      'Your certificate for "' + aTitle + '" is ready:\n' + certUrl + '\n\n' +
      'Thank you.';
    var bodyHtml =
      '<p>Dear ' + safeTrim_(name) + ',</p>' +
      '<p>Your certificate for "<b>' + safeTrim_(aTitle) + '</b>" is ready:</p>' +
      '<p><a href="' + certUrl + '">Open certificate (PDF)</a></p>' +
      '<p>Thank you.</p>';

    MailApp.sendEmail({
      to: email,
      subject: subject,
      body: bodyText,
      htmlBody: bodyHtml,
      name: 'Certificates'
    });

    emailStatus = sentAt;
  } else {
    emailStatus = 'No recipient email';
  }

  return { certificateUrl: certUrl, emailStatus: emailStatus };
}

// --------------------- Drive REST helpers ----------------------------
/** Convert PPT/PPTX blob into Google Slides using Drive v3 REST. */
function driveCreateGoogleSlidesFromOffice_(officeBlob, newTitle, parentFolderId) {
  var boundary = '-------314159265358979323846';
  var delimiter = '\r\n--' + boundary + '\r\n';
  var closeDelim = '\r\n--' + boundary + '--';

  var metadata = {
    name: newTitle || (officeBlob.getName() || 'Imported Slides'),
    mimeType: 'application/vnd.google-apps.presentation',
    parents: parentFolderId ? [parentFolderId] : []
  };

  var body =
    delimiter +
    'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
    JSON.stringify(metadata) + '\r\n' +
    delimiter +
    'Content-Type: ' + (officeBlob.getContentType() || 'application/vnd.openxmlformats-officedocument.presentationml.presentation') + '\r\n' +
    'Content-Transfer-Encoding: base64\r\n' +
    '\r\n' +
    Utilities.base64Encode(officeBlob.getBytes()) +
    closeDelim;

  var params = {
    method: 'post',
    contentType: 'multipart/related; boundary=' + boundary,
    payload: body,
    headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
    muteHttpExceptions: true
  };

  var url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType';
  var res = UrlFetchApp.fetch(url, params);
  if (res.getResponseCode() >= 300) {
    throw new Error('Drive upload failed (' + res.getResponseCode() + '): ' + res.getContentText());
  }
  var obj = JSON.parse(res.getContentText());
  return { id: obj.id, name: obj.name, mimeType: obj.mimeType };
}

/** Export a Google file as PDF using Drive v3 REST. */
function driveExportFileAsPdf_(fileId) {
  var url = 'https://www.googleapis.com/drive/v3/files/' + encodeURIComponent(fileId) +
            '/export?mimeType=application/pdf';
  var res = UrlFetchApp.fetch(url, {
    method: 'get',
    headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() },
    muteHttpExceptions: true
  });
  if (res.getResponseCode() >= 300) {
    throw new Error('Drive export failed (' + res.getResponseCode() + '): ' + res.getContentText());
  }
  var blob = res.getBlob();
  blob.setName('export.pdf');
  return blob;
}

// ========================= Admin API for Activity sheet ======================
/* Expected Activity sheet columns (A..I):
 *  A: Title
 *  B: Venue
 *  C: fromDate
 *  D: toDate
 *  E: Certificate Template (URL or text)
 *  F: Focal-in-Charge
 *  G: Timestamp (auto-managed here)
 *  H: Date Given
 *  I: ActivityID   <-- NEW last field
 */

// Map a single Activity row → object using header-based column indices
function _activityRowToObj_(rowValues, rowIndex, cols) {
  function cell(c) {
    return (typeof c === 'number' && c >= 0 && c < rowValues.length)
      ? rowValues[c]
      : '';
  }

  var tsVal = cell(cols.timestamp);
  var tsOut;
  if (tsVal instanceof Date) {
    tsOut = Utilities.formatDate(
      tsVal,
      Session.getScriptTimeZone() || 'Asia/Manila',
      'yyyy-MM-dd HH:mm'
    );
  } else {
    tsOut = safeTrim_(tsVal);
  }

  return {
    id: rowIndex, // visible sheet row number (2..)
    title:     safeTrim_(cell(cols.title)),
    venue:     safeTrim_(cell(cols.venue)),
    fromDate:  fmtDate_(cell(cols.fromDate)),
    toDate:    fmtDate_(cell(cols.toDate)),
    template:  safeTrim_(cell(cols.template)),
    inCharge:  safeTrim_(cell(cols.inCharge)),
    Timestamp: tsOut,
    givenDate: fmtDate_(cell(cols.givenDate)),
    activityId: safeTrim_(cell(cols.activityId))
  };
}

/** GET: list activities for admin table (header-based, column-order safe) */
function adminGetActivities() {
  if (ENFORCE_WHITELIST && !isWhitelisted_(getViewerEmail_())) {
    throw new Error('Forbidden: you are not whitelisted.');
  }

  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Activity');
  if (!sh) throw new Error("Sheet 'Activity' not found.");

  var lastRow = sh.getLastRow();
  var lastCol = sh.getLastColumn();
  if (lastRow < 2 || lastCol < 1) return [];

  var hdr = getHeaderMap_(sh);

  // Resolve all needed columns ONCE using header names / aliases
  var cols = {
    title:      idxOf_(hdr, ['title','activity title','activity']),
    venue:      idxOf_(hdr, ['venue','location']),
    fromDate:   idxOf_(hdr, ['fromdate','from date','start']),
    toDate:     idxOf_(hdr, ['todate','to date','end']),
    template:   idxOf_(hdr, ['certificate template','template']),
    inCharge:   idxOf_(hdr, ['focal-in-charge','focal in charge','in-charge','in charge']),
    timestamp:  idxOf_(hdr, ['timestamp','created at','last updated']),
    givenDate:  idxOf_(hdr, ['given date','date given','givendate','issued','schedule']),
    activityId: idxOf_(hdr, ['activityid','activity id','id'])
  };

  var values = sh.getRange(2, 1, lastRow - 1, lastCol).getValues();
  var out = [];

  for (var i = 0; i < values.length; i++) {
    out.push(_activityRowToObj_(values[i], i + 2, cols));
  }
  return out;
}

/** SAVE (insert or update) an activity row
 * payload: {id?, title, venue, fromDate, toDate, template, inCharge, givenDate, date?, activityId?}
 * - If activityId is blank on insert, we generate one.
 * - On update, if sheet cell is blank, we also generate and write it.
 */
function adminSaveActivity(payload) {
  if (ENFORCE_WHITELIST && !isWhitelisted_(getViewerEmail_())) {
    throw new Error('Forbidden: you are not whitelisted.');
  }

  payload = payload || {};
  var title    = safeTrim_(payload.title);
  var venue    = safeTrim_(payload.venue);
  var fromDate = fmtDate_(payload.fromDate || payload.date);
  var toDate   = fmtDate_(payload.toDate);
  var template = safeTrim_(payload.template);
  var inCharge = safeTrim_(payload.inCharge);
  var givenDate= fmtDate_(payload.givenDate);
  var rowId    = parseInt(String(payload.id || ''), 10);
  var activityId = safeTrim_(payload.activityId);

  if (!title || !venue || !fromDate || !inCharge || !template) {
    throw new Error('Please fill all required fields (Title, Venue, fromDate, Certificate Template, Focal-in-Charge).');
  }

  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Activity');
  if (!sh) throw new Error("Sheet 'Activity' not found.");

  // Ensure we have an ActivityID for new rows or blank ones
  if (!activityId) activityId = makeActivityId_();

  var now = new Date();
  var rowValues = [
    title,            // A Title
    venue,            // B Venue
    fromDate,         // C fromDate
    toDate,           // D toDate
    template,         // E Certificate Template (URL or text)
    inCharge,         // F Focal-in-Charge
    now,              // G Timestamp
    givenDate,        // H Date Given
    activityId        // I ActivityID
  ];

  if (isFinite(rowId) && rowId >= 2) {
    // UPDATE existing row
    sh.getRange(rowId, 1, 1, rowValues.length).setValues([rowValues]);
  } else {
    // INSERT new row
    sh.appendRow(rowValues);
  }
  return 'OK';
}

/** DELETE a row by its sheet row index (the "Row" shown in the table) */
function adminDeleteActivity(id) {
  if (ENFORCE_WHITELIST && !isWhitelisted_(getViewerEmail_())) {
    throw new Error('Forbidden: you are not whitelisted.');
  }
  var rowId = parseInt(String(id || ''), 10);
  if (!isFinite(rowId) || rowId < 2) throw new Error('Invalid row id.');

  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Activity');
  if (!sh) throw new Error("Sheet 'Activity' not found.");

  var lastRow = sh.getLastRow();
  if (rowId > lastRow) throw new Error('Row does not exist.');
  sh.deleteRow(rowId);
  return 'OK';
}

/**
 * Admin: re-run certificate + email for a given Responses row index.
 * - rowIndex is the sheet row number in the "Responses" sheet (2..n).
 * - Only whitelisted users can call this.
 * - Updates certificate URL, email sent, and cStatus columns.
 * Returns: { status, certificateUrl, emailStatus }
 */
function adminReprocessCertificate(rowIndex) {
  if (ENFORCE_WHITELIST && !isWhitelisted_(getViewerEmail_())) {
    throw new Error('Forbidden: you are not whitelisted.');
  }

  var rowId = parseInt(String(rowIndex || ''), 10);
  if (!isFinite(rowId) || rowId < 2) {
    throw new Error('Invalid Responses row index (must be ≥ 2).');
  }

  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Responses');
  if (!sh) throw new Error("Sheet 'Responses' not found.");

  var lastRow = sh.getLastRow();
  if (rowId > lastRow) {
    throw new Error('Responses row ' + rowId + ' does not exist.');
  }

  // Resolve columns once
  var hdr = getHeaderMap_(sh);
  var cEmailSent = idxOf_(hdr, ['email sent','emailsent','email_sent','sent','date emailed']);
  var cCertLink  = idxOf_(hdr, ['certificate','certificate link','cert link','certificate url']);
  var cStatus    = idxOf_(hdr, ['cstatus','status','processing status']);

  try {
    // Mark as PENDING before reprocess (if status column exists)
    if (cStatus >= 0) {
      sh.getRange(rowId, cStatus + 1).setValue('PENDING');
    }

    // Do the heavy work using the existing helper
    var meta = sendCertificateForResponse_(rowId);

    // Update post-processing fields
    if (cCertLink  >= 0) sh.getRange(rowId, cCertLink  + 1).setValue(meta.certificateUrl || '');
    if (cEmailSent >= 0) sh.getRange(rowId, cEmailSent + 1).setValue(meta.emailStatus || 'No recipient email');
    if (cStatus    >= 0) sh.getRange(rowId, cStatus    + 1).setValue('OK');

    return {
      status: 'OK',
      certificateUrl: meta.certificateUrl || '',
      emailStatus: meta.emailStatus || ''
    };
  } catch (e) {
    // Mark as ERROR and bubble up for the admin UI to see
    try {
      if (cStatus >= 0) {
        sh.getRange(rowId, cStatus + 1).setValue('ERROR: ' + e.message);
      }
    } catch (_) {}
    throw e;
  }
}

/** UPLOAD template PPT/PPTX from the admin UI overlay
 * fileObj: { filename, mimeType, base64 }
 * Returns: { id, name, url }
 */
function adminUploadTemplate(fileObj) {
  if (ENFORCE_WHITELIST && !isWhitelisted_(getViewerEmail_())) {
    throw new Error('Forbidden: you are not whitelisted.');
  }
  if (!fileObj || !fileObj.base64 || !fileObj.filename) {
    throw new Error('No file payload.');
  }

  var folder = assertFolder_(TEMPLATE_FOLDER_ID, 'Template folder');
  var bytes = Utilities.base64Decode(fileObj.base64);
  var blob = Utilities.newBlob(bytes, fileObj.mimeType || 'application/vnd.ms-powerpoint', fileObj.filename);

  var file = folder.createFile(blob);
  try { file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (_){}

  return { id: file.getId(), name: file.getName(), url: file.getUrl() };
}

/** Whitelist names for admin dropdown */
function adminGetWhitelistNames() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName('Whitelist');
  if (!sh) return [];

  var lastRow = sh.getLastRow();
  if (lastRow < 2) return [];

  var hdr = getHeaderMap_(sh);
  var cName = idxOf_(hdr, ['name','full name','whitelist name']);
  if (cName < 0) return [];

  var vals = sh.getRange(2, cName + 1, lastRow - 1, 1).getValues();
  var out = [], seen = {};
  for (var i = 0; i < vals.length; i++) {
    var v = safeTrim_(vals[i][0]);
    if (!v) continue;
    var key = v.toLowerCase();
    if (seen[key]) continue;
    seen[key] = true;
    out.push(v);
  }
  return out;
}

/** Identity flag for admin badge */
function adminWhoAmI() {
  var email = getViewerEmail_(); // blank for anonymous on public deploys
  var authorized = !ENFORCE_WHITELIST || isWhitelisted_(email);
  return { email: email, authorized: authorized };
}
